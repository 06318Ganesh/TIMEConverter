let covnvertBtnEl = document.getElementById("convertBtn");

covnvertBtnEl.addEventListener("click", function getseconds() {
    let hoursInputEl = parseInt(document.getElementById("hoursInput").value);
    let minutesInputEl = parseInt(document.getElementById("minutesInput").value);
    let seconds = ((hoursInputEl) * 60 + minutesInputEl) * 60;

    let errMsgEl = document.getElementById("errorMsg");
    let showSeconds = document.getElementById("timeInSeconds");

    if (isNaN(hoursInputEl) || isNaN(minutesInputEl)) {
        errMsgEl.textContent = "please enter any name";
        errMsgEl.style.color = "#f5f7fa";
    } else {
        showSeconds.textContent = seconds;
        showSeconds.style.color = "#ffffff";
    }

})